<?php include "about.html."
?>

<?php include "foot.html"
?>