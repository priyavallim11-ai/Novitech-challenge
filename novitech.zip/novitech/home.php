<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>


<nav class="navbar">
    <div class="logo">
        <h1>✈ Wanderly</h1>
    </div>

    <ul>
        <li><a href="home.php">Home</a></li>
        <li><a href="body.php">About</a></li>
        <li><a href="explore.html">Explore</a></li>
        <li><a href="contact.html">Contact</a></li>
       
    </ul>
    <div class="user">

    <input type="checkbox" id="profile">

    <label for="profile" class="profile-btn">
        👤 Priya
    </label>

    <div class="sidebar">

        <label for="profile" class="close">&times;</label>

        <img src="profile.png" alt="Profile">

        <h2>Priya</h2>

        <p>MSc Software Systems</p>

        <hr>
        <a href="dashboard.html"> History & Recommends</a>

       <a href="profile.html">👤 My Profile</a>

<a href="trips.html">✈ My Trips</a>

<a href="order.html">📦 My Orders</a>

<a href="wishlist.html">❤️ Wishlist</a>

<a href="settings.html">⚙ Settings</a>

<a href="login.html" class="logout">🚪 Logout</a>

       

    </div>

</div>
       

</div>
</nav>

<section class="section">

    <h1>Explore The Beauty Of The World</h1>

    <p>
        Let's discover amazing places at exclusive deals and make your journey unforgettable.
    </p>

    <div class="buttons">
        <button class="btn1">Explore Now</button>
        <button class="btn2">Learn More</button>
    </div>

</section>


<section class="search">

    <div class="search-box">
        <label>Location</label>
        <input type="text" placeholder="Where are you going?">
    </div>

    <div class="search-box">
        <label>Check In</label>
        <input type="date">
    </div>

    <div class="search-box">
        <label>Check Out</label>
        <input type="date">
    </div>

    <div class="search-box">
        <label>Guests</label>
        <input type="number" placeholder="2">
    </div>

    <button class="search-btn">Search</button>

</section>


<section class="popular">

    <div class="view">
        <h2>Popular Destinations</h2>
        <a href="#">View All</a>
    </div>

    <div class="images">

        <div class="card">
            <img src="alapuzha.jpg" alt="">
            <h3>Alappuzha</h3>
            <p>From ₹699</p>
        </div>

        <div class="card">
            <img src="delhi.jpg" alt="">
            <h3>Delhi</h3>
            <p>From ₹899</p>
        </div>

        <div class="card">
            <img src="mysore.jpg" alt="">
            <h3>Mysore</h3>
            <p>From ₹999</p>
        </div>

        <div class="card">
            <img src="rishikesh.jpg" alt="">
            <h3>Rishikesh</h3>
            <p>From ₹2499</p>
        </div>

    </div>

</section>

</body>
</html>