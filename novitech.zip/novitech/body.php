<?php include "about.html";
 ?>

<body>

<div class="travel">
    <h1>Why Travel With Us?</h1>
</div>

<section class="body">

    <div class="best">
        <h1>Best Prices</h1>
        <p>
            We offer the best prices<br>
            and amazing deals<br>
            for your journey.
        </p>
    </div>

    <div class="Trusted">
        <h1>Trusted Services</h1>
        <p>
            Our team is available<br>
            24 hours a day<br>
            to assist you.
        </p>
    </div>

    <div class="hotels">
        <h1>Handpicked Hotels</h1>
        <p>
            We partner with top-rated hotels<br>
            for your comfortable stay.
        </p>
    </div>

</section>

</body>

<?php include "foot.html";
?>