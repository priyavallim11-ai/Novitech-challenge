// ===============================
// Filter Destinations
// ===============================

const filterButtons = document.querySelectorAll(".filter-btn");
const cards = document.querySelectorAll(".card");

filterButtons.forEach(function(button){

    button.addEventListener("click",function(){

        // Remove active class
        filterButtons.forEach(function(btn){
            btn.classList.remove("active");
        });

        // Add active class
        this.classList.add("active");

        const filter = this.getAttribute("data-filter");

        cards.forEach(function(card){

            if(filter === "all"){

                card.style.display = "block";

            }
            else if(card.classList.contains(filter)){

                card.style.display = "block";

            }
            else{

                card.style.display = "none";

            }

        });

    });

});


// ===============================
// Modal Popup
// ===============================

const modal = document.getElementById("modal");
const modalTitle = document.getElementById("modalTitle");
const modalText = document.getElementById("modalText");

const closeModal = document.getElementById("closeModal");

const detailButtons = document.querySelectorAll(".details-btn");

detailButtons.forEach(function(btn){

    btn.addEventListener("click",function(){

        const card = this.parentElement;

        const place = card.querySelector("h3").innerText;

        const country = card.querySelector("p").innerText;

        modal.style.display = "flex";

        modalTitle.innerText = place;

        modalText.innerText =
        place +
        " is one of the most beautiful tourist destinations in " +
        country +
        ". Enjoy wonderful sightseeing, delicious food and unforgettable memories.";

    });

});


closeModal.addEventListener("click",function(){

    modal.style.display = "none";

});


window.addEventListener("click",function(e){

    if(e.target==modal){

        modal.style.display="none";

    }

});


// ===============================
// Book Button
// ===============================

document.getElementById("bookBtn").addEventListener("click",function(){

    const answer = confirm("Do you want to book this destination?");

    if(answer){

        alert("Booking Successful!");

    }
    else{

        alert("Booking Cancelled");

    }

});


// ===============================
// Dynamic Popular Badge
// createElement()
// appendChild()
// ===============================

cards.forEach(function(card,index){

    if(index<2){

        const badge=document.createElement("span");

        badge.innerText="POPULAR";

        badge.classList.add("badge");

        card.appendChild(badge);

    }

});


cards.forEach(function(card){

    card.addEventListener("dblclick",function(){

        card.classList.toggle("favourite");

    });

});



cards.forEach(function(card){

    card.addEventListener("mouseover",function(){

        card.style.transform="scale(1.03)";

    });

    card.addEventListener("mouseout",function(){

        card.style.transform="scale(1)";

    });

});



cards.forEach(function(card){

    const image = card.querySelector("img");

    const alt = image.getAttribute("alt");

    image.setAttribute("title",alt);

});



const hero = document.querySelector(".hero");

hero.addEventListener("dblclick",function(){

    hero.removeAttribute("title");

});




const footer = document.querySelector("footer");

const oldText = footer.querySelector("p");

const newText = document.createElement("p");

newText.innerText = "🌍 Happy Journey with Wanderly!";

footer.replaceChild(newText, oldText);