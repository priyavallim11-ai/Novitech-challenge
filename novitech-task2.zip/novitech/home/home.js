
const visitor = prompt("Welcome to Wanderly!\nEnter your name:");

if(visitor){

    alert("Welcome " + visitor + " 😊");

}

document.addEventListener("DOMContentLoaded", function () {

    setTimeout(function () {

        document.getElementById("loader").style.display = "none";
        document.getElementById("main-content").style.display = "block";

    }, 2000);

});

let welcomeTimer = setTimeout(function(){

    alert("Enjoy exploring Wanderly!");

},5000);

clearTimeout(welcomeTimer);



function updateClock() {

    const now = new Date();

    let h = now.getHours();
    let m = now.getMinutes();
    let s = now.getSeconds();

    h = String(h).padStart(2, "0");
    m = String(m).padStart(2, "0");
    s = String(s).padStart(2, "0");

    document.getElementById("clock").innerText =
        h + ":" + m + ":" + s;

}

updateClock();

setInterval(updateClock, 1000);


const destinationCards = document.getElementsByClassName("card");

console.log("Total Cards :", destinationCards.length);

const headings = document.getElementsByTagName("h3");

console.log("Destination Names");

for(let i=0;i<headings.length;i++){

    console.log(headings[i].innerText);

}
const themeBtn = document.getElementById("themeBtn");

if (localStorage.getItem("theme") === "dark") {

    document.body.classList.add("dark-mode");

    themeBtn.innerHTML = "☀ Light Mode";

}

themeBtn.addEventListener("click", function () {

    document.body.classList.toggle("dark-mode");

    if (document.body.classList.contains("dark-mode")) {

        localStorage.setItem("theme", "dark");

        themeBtn.innerHTML = "☀ Light Mode";

    } else {

        localStorage.setItem("theme", "light");

        themeBtn.innerHTML = "🌙 Dark Mode";

    }

});

const hero = document.getElementById("heroSection");

const sliderImages = [

    "../images/home1.jpg",
    "../images/home2.jpg",
    "../images/home3.jpg",
    "../images/home4.jpg"

];

let index = 0;

function changeImage() {

    hero.style.backgroundImage =
        "url('" + sliderImages[index] + "')";

    index++;

    if (index >= sliderImages.length) {

        index = 0;

    }

}

changeImage();

let slider = setInterval(changeImage, 3000);



hero.addEventListener("mouseover", function () {

    clearInterval(slider);

});

hero.addEventListener("mouseout", function () {

    slider = setInterval(changeImage, 3000);

});

window.addEventListener("scroll", function () {

    let scrollTop = document.documentElement.scrollTop;

    let scrollHeight =
        document.documentElement.scrollHeight -
        document.documentElement.clientHeight;

    let progress = (scrollTop / scrollHeight) * 100;

    document.getElementById("progress-bar").style.width =
        progress + "%";

});



const topBtn = document.getElementById("topBtn");

if (topBtn) {

    window.addEventListener("scroll", function () {

        if (window.scrollY > 300) {

            topBtn.style.display = "block";

        } else {

            topBtn.style.display = "none";

        }

    });

    topBtn.addEventListener("click", function () {

        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });

    });

}

const searchInput = document.getElementById("searchInput");
const cards = document.querySelectorAll(".card");

if (searchInput) {

    searchInput.addEventListener("input", function () {

        const searchText = this.value.trim().toLowerCase();

        cards.forEach(function (card) {

            const place = card.querySelector("h3").textContent.toLowerCase();

            if (place.includes(searchText)) {

                card.style.display = "";

            } else {

                card.style.display = "none";

            }

        });

    });

}
const profileName = document.getElementById("profileName");

const username = sessionStorage.getItem("username");

if(username){

    profileName.innerHTML = "👤 " + username;

}

const removeBtn = document.getElementById("removeCard");

removeBtn.addEventListener("click",function(){

    const cardContainer = document.querySelector(".images");

    if(cardContainer.lastElementChild){

        cardContainer.removeChild(cardContainer.lastElementChild);

        alert("Last destination removed.");

    }

});