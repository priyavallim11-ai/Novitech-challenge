<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page</title>

    <link rel="stylesheet" href="../home/style.css">
</head>

<body>
<div id="progress-container">
    <div id="progress-bar"></div>
</div>

<div id="loader">
    <div class="spinner"></div>
    <h2>Loading...</h2>
</div>

<div id="main-content">

<nav class="navbar">

    <div class="logo">
        <h1>✈ Wanderly</h1>
    </div>
    <div class="clock" id="clock">
    00:00:00
</div>
  

    <ul>
        <li><a href="home.php">Home</a></li>
        <li><a href="../about/body.php">About</a></li>
        <li><a href="../explore/explore.html">Explore</a></li>
        <li><a href="../contact/contact.html">Contact</a></li>
    </ul>
      <button id="themeBtn" class="theme-btn">
    🌙 Dark Mode
</button>



    <div class="user">

        <input type="checkbox" id="profile">

        <label for="profile" class="profile-btn" id="profileName">
            👤 Priya
        </label>

        

        <div class="sidebar">

            <label for="profile" class="close">&times;</label>

            <img src="../images/profile.png" alt="Profile">

            <h2>Priya</h2>

            <p>MSc Software Systems</p>

            <hr>

            <a href="../dashboard/dashboard.html">📜 History & Recommends</a>

            <a href="../profile/profile.html">👤 My Profile</a>

            <a href="../trips/trips.html">✈ My Trips</a>

            <a href="../order/order.html">📦 My Orders</a>

            <a href="../wishlist/wishlist.html">❤️ Wishlist</a>

            <a href="../settings/settings.html">⚙ Settings</a>

            <a href="../login/login.html" class="logout">🚪 Logout</a>

          
        </div>


    </div>

</nav>


<section class="section" id="heroSection">

    <h1>Explore The Beauty Of The World</h1>

    <p>
        Let's discover amazing places at exclusive deals and make your journey unforgettable.
    </p>

    <div class="buttons">
        <button class="btn1">Explore Now</button>
        <button class="btn2">Learn More</button>
    </div>

</section>



<section class="search">

    <div class="search-box">
        <label>Location</label>
        <input type="text" id="searchInput" placeholder="Search destination">
    </div>

    <div class="search-box">
        <label>Check In</label>
        <input type="date">
    </div>

    <div class="search-box">
        <label>Check Out</label>
        <input type="date">
    </div>

    <div class="search-box">
        <label>Guests</label>
        <input type="number" placeholder="2">
    </div>

    <button class="search-btn">Search</button>

    <button id="removeCard" class="search-btn">
Remove Last Card
</button>

</section>



<section class="popular">

    <div class="view">

        <h2>Popular Destinations</h2>

        <a href="#">View All</a>

    </div>

    <div class="images">

        <div class="card">
            <img src="../images/alapuzha.jpg" alt="Alappuzha">
            <h3>Alappuzha</h3>
            <p>From ₹699</p>
        </div>

        <div class="card">
            <img src="../images/delhi.jpg" alt="Delhi">
            <h3>Delhi</h3>
            <p>From ₹899</p>
        </div>

        <div class="card">
            <img src="../images/mysore.jpg" alt="Mysore">
            <h3>Mysore</h3>
            <p>From ₹999</p>
        </div>

        <div class="card">
            <img src="../images/rishikesh.jpg" alt="Rishikesh">
            <h3>Rishikesh</h3>
            <p>From ₹2499</p>
        </div>

    </div>

</section>

</div>
<button id="topBtn">⬆</button>


<script src="../home/home.js"></script>

</body>

</html>