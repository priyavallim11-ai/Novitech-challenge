const form = document.getElementById("contactForm");

const name = document.getElementById("name");
const email = document.getElementById("email");
const phone = document.getElementById("phone");
const message = document.getElementById("message");

form.addEventListener("submit", function(e){

    e.preventDefault();

    let valid = true;

    document.getElementById("nameError").innerText = "";
    document.getElementById("emailError").innerText = "";
    document.getElementById("phoneError").innerText = "";
    document.getElementById("messageError").innerText = "";


    name.classList.remove("invalid","success");
    email.classList.remove("invalid","success");
    phone.classList.remove("invalid","success");
    message.classList.remove("invalid","success");

    
    if(name.value.trim().length < 3){

        document.getElementById("nameError").innerText =
        "Name must contain at least 3 characters.";

        name.classList.add("invalid");
        valid = false;

    }else{

        name.classList.add("success");

    }

    
    const emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;

    if(!emailPattern.test(email.value)){

        document.getElementById("emailError").innerText =
        "Enter a valid email.";

        email.classList.add("invalid");
        valid = false;

    }else{

        email.classList.add("success");

    }


    const phonePattern = /^[0-9]{10}$/;

    if(!phonePattern.test(phone.value)){

        document.getElementById("phoneError").innerText =
        "Phone number must contain 10 digits.";

        phone.classList.add("invalid");
        valid = false;

    }else{

        phone.classList.add("success");

    }

    if(message.value.trim().length < 20){

        document.getElementById("messageError").innerText =
        "Message should contain at least 20 characters.";

        message.classList.add("invalid");
        valid = false;

    }else{

        message.classList.add("success");

    }

    if(valid){

       const toast = document.getElementById("toast");

toast.classList.add("show");

setTimeout(function(){

    toast.classList.remove("show");

},3000);
        form.reset();

        name.classList.remove("success");
        email.classList.remove("success");
        phone.classList.remove("success");
        message.classList.remove("success");

    }

});

document.querySelectorAll("input, textarea").forEach(function(field){

    field.addEventListener("focus", function(){

        this.style.backgroundColor = "#eef7ff";

    });

    field.addEventListener("blur", function(){

        this.style.backgroundColor = "";

    });

});