// Login Form

const loginForm = document.getElementById("loginForm");

loginForm.addEventListener("submit", function(e){

    e.preventDefault();

    const username = document.getElementById("username").value;

    const password = document.getElementById("password").value;

    if(username==="" || password===""){

        alert("Please enter Username and Password");

        return;

    }

    // Save username for current session
    sessionStorage.setItem("username", username);

    alert("Login Successful!");

    window.location.href="../home/home.php";

});