<?php include "about.html"; ?>

<body>

<div class="travel">
    <h1>Why Travel With Us?</h1>
</div>

<section class="body">

    <div class="best">
        <h1>Best Prices</h1>
        <p>
            We offer the best prices<br>
            and amazing deals<br>
            for your journey.
        </p>
    </div>

    <div class="Trusted">
        <h1>Trusted Services</h1>
        <p>
            Our team is available<br>
            24 hours a day<br>
            to assist you.
        </p>
    </div>

    <div class="hotels">
        <h1>Handpicked Hotels</h1>
        <p>
            We partner with top-rated hotels<br>
            for your comfortable stay.
        </p>
    </div>

</section>
<section class="stats">

    <div class="stat-box">
        <h2 class="counter" data-target="500">0</h2>
        <p>Destinations</p>
    </div>

    <div class="stat-box">
        <h2 class="counter" data-target="10000">0</h2>
        <p>Happy Travelers</p>
    </div>

    <div class="stat-box">
        <h2 class="counter" data-target="250">0</h2>
        <p>Hotels</p>
    </div>

    <div class="stat-box">
        <h2 class="counter" data-target="50">0</h2>
        <p>Travel Experts</p>
    </div>

</section>



<section class="about-more">

    <h2>About Wanderly</h2>

    <p id="moreText">

        Wanderly helps travelers explore beautiful destinations, compare travel packages,
        discover hotels, and enjoy memorable vacations. Our goal is to make travel planning
        simple, affordable, and enjoyable for everyone.

        <span id="dots">...</span>

        <span id="extraText" style="display:none;">

            We provide trusted services, secure booking, expert travel guidance,
            and personalized recommendations. Whether you're planning a family vacation,
            honeymoon, solo adventure, or business trip, Wanderly is your trusted travel partner.

        </span>

    </p>

    <button id="readBtn">Read More</button>

</section>
<section class="quote-section">

    <h2>Travel Inspiration</h2>

    <div class="quote-box">

        <p id="quote">
            "Travel is the only thing you buy that makes you richer."
        </p>

        <button id="quoteBtn">
            ✈ Inspire Me
        </button>

    </div>

</section>



<section class="faq">

    <h2>Frequently Asked Questions</h2>

    <div class="faq-item">
        <button class="faq-question">What is Wanderly?</button>

        <div class="faq-answer">
            <p>
                Wanderly is a travel website that helps users discover beautiful destinations,
                compare packages and book memorable trips.
            </p>
        </div>
    </div>

    <div class="faq-item">
        <button class="faq-question">How can I book a trip?</button>

        <div class="faq-answer">
            <p>
                Simply browse destinations, select a package and complete the booking process.
            </p>
        </div>
    </div>

    <div class="faq-item">
        <button class="faq-question">Are travel packages affordable?</button>

        <div class="faq-answer">
            <p>
                Yes. We offer packages suitable for different budgets.
            </p>
        </div>
    </div>

</section>

<script src="about.js"></script>

</body>

<?php include "foot.html"; ?>