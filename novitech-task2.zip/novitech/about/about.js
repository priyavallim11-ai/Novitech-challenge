const questions = document.querySelectorAll(".faq-question");

questions.forEach(function(question){

    question.addEventListener("click", function(){

        this.classList.toggle("active");

        const answer = this.nextElementSibling;

        if(answer.style.display === "block"){

            answer.style.display = "none";

        }else{

            answer.style.display = "block";

        }

    });

});
const counters = document.querySelectorAll(".counter");

counters.forEach(counter=>{

    const update=()=>{

        const target=+counter.getAttribute("data-target");

        const current=+counter.innerText;

        const increment=Math.ceil(target/100);

        if(current<target){

            counter.innerText=current+increment;

            setTimeout(update,20);

        }else{

            counter.innerText=target+"+";

        }

    }

    update();

});

// ===============================
// Random Travel Quote Generator
// ===============================

const quotes = [

    "Travel is the only thing you buy that makes you richer.",

    "Life is short and the world is wide.",

    "Adventure awaits those who seek it.",

    "Collect moments, not things.",

    "Travel far enough to meet yourself.",

    "Wherever you go becomes a part of you.",

    "The journey is the destination.",

    "Take only memories, leave only footprints."

];

const quoteBtn = document.getElementById("quoteBtn");
const quote = document.getElementById("quote");

quoteBtn.addEventListener("click", function(){

    const randomIndex = Math.floor(Math.random() * quotes.length);

    quote.textContent = '"' + quotes[randomIndex] + '"';

});